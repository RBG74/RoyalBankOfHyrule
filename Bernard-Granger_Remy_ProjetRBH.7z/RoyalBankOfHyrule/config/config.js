module.exports = {
    'sessionKey': 'BananaLame'
}